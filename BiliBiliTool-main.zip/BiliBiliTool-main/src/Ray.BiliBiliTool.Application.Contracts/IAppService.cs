﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ray.BiliBiliTool.Application.Contracts
{
    /// <summary>
    /// 定义一个AppService
    /// </summary>
    public interface IAppService
    {
    }
}
