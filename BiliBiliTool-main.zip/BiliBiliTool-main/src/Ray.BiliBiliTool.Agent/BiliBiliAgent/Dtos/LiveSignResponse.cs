﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class LiveSignResponse
    {
        public string Text { get; set; }

        public string SpecialText { get; set; }
    }
}
