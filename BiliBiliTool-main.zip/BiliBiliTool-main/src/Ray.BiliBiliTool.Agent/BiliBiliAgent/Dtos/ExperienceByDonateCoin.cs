﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class ExperienceByDonateCoin
    {
        public int Code { get; set; } = int.MinValue;

        public string Message { get; set; }

        public int Number { get; set; } = int.MinValue;
    }
}
